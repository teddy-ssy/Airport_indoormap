package com.example.voice;

import java.util.ArrayList;

import android.media.Ringtone;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.speech.RecognizerIntent;
import android.support.v4.app.NavUtils;

public class MainActivity extends Activity {
	private Button btnVoice;
	private TextView tvVoiceResult;
	private static final int VOICE_RECOGNITION_REQUEST_CODE = 123456;
	
	private Handler jumpHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			tvVoiceResult.setText((String)msg.obj);
		};
	};
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnVoice = (Button) findViewById(R.id.btnVoice);
        tvVoiceResult = (TextView) findViewById(R.id.tvVoiceResult);
        btnVoice.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				try {
			        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
			        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
			        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "�뿪ʼ˵��");
			        startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
				}catch(ActivityNotFoundException e) {
					AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
					builder.setTitle("����ʶ��");
					builder.setMessage("�����ֻ��ݲ�֧�������������ܣ����ȷ�����ذ�װGoogle����������������Ҳ�����ڸ�Ӧ���̵������������������������ذ�װ��");
					builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
//							��ת������������ҳ
						}
					});
					builder.setNegativeButton("ȡ��", null);
					builder.show();
				}
			}
		});
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_RECOGNITION_REQUEST_CODE && resultCode == MainActivity.RESULT_OK) {
        	ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        	if(matches.size() > 0) {
	        	Message msg = new Message();
	        	msg.obj = matches.get(0);
	        	jumpHandler.sendMessage(msg);
        	}
        }
    }
    
}
