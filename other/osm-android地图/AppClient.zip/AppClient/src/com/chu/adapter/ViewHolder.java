package com.chu.adapter;

import android.widget.Button;
import android.widget.TextView;

public final class ViewHolder {
	public TextView from;
    public TextView to;
    public TextView time;
    public Button mBtn;
}
