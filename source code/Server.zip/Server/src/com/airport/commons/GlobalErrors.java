package com.airport.commons;

public class GlobalErrors {
	
	public static int nameAlreadyExists = -10;
	public static int nameDoesnotExists = -16;
}
