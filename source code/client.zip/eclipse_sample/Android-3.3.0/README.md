# Insiteo Android sample application
=======


Insiteo is a provider of indoor location based services such as :

- Map rendering
- Location
- Itinerary
- Geofencing 

This sample application will demonstrate how to take full advantage of those services and integrate them in your application.

For further integration documentation you can have a look at the developer's site: http://dev.insiteo.com/api

## Create your account

If you wish to evaluate indoor location in your own building, you can order our test pack including 8 BLE beacons here:
http://www.insiteo.com/joomla/index.php/en/contact-us.

## More informations

If you want more information on our services http://www.insiteo.com/joomla/index.php





