package com.insiteo.sampleapp.render;

import com.insiteo.lbs.map.render.GenericRTO;

/**
 * @author Insiteo
 *
 */
public class GfxRto extends GenericRTO {
	

	public GfxRto() {
		super();
	}

	

}
