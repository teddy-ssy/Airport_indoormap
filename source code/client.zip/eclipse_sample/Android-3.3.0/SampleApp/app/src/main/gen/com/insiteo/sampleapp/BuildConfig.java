/** Automatically generated file. DO NOT MODIFY */
package com.insiteo.sampleapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}