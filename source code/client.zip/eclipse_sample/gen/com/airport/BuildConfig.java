/** Automatically generated file. DO NOT MODIFY */
package com.airport;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}