package com.airport.util;

public class Constants {
    /*
     * 请登录http://developer.baidu.com，注册成为百度开发者，创建应用并开通语音技术服务后，
     * 将对应的ApiKey和SecretKey填写后再测试
     */
    public static final String API_KEY = "DkYncsPcWcQOZEBlqzcLxIdq";

    public static final String SECRET_KEY = "c6d5123daa787b572ffd7441e2c87ef6";
    
    public static Boolean HAS_SEARCHSHOP = false;
    
    public static String TempSerchContent="";
    
    public static String AIRPORT="北京";
     
    public static String CAR=null;
    
    public static String ENTERANCE=null;
    
    public static String TAKEOFF =null;
    
    public static String ARRIVAL =null;
    
    public static String ENDAIRPORT=null;
    
    public static String FIGHTNUMBER=null;
    
    public static Boolean HAS_IP = false;

}
