package com.airport.twodimensioncode;
import android.app.Activity;
import android.os.Bundle;

public class BarCodeActivity  extends Activity{
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
	}

}
