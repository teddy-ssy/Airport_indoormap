package com.airport.commons;

public class GlobalInts {
	
	// for self-defined ids
	public static final int idFrdReqNotifItemSt = 1;
	
	// maximum number of friends can have
	public static final int MaxFriendNumber = 1000;
}
